import SwiftUI

struct ContentView: View {
    var meuArray: [String] = ["banana", 
                             "kiwi", 
                             "morango", 
                             "pera", 
                             "uva", 
                             "jabuticaba"]
    
    var body: some View {
        VStack(alignment: .leading) {
            HStack{
                Image(systemName: "text.book.closed.fill")
                    .foregroundColor(.red)
                    .imageScale(.large)
                Text("Oba, bao?")
                    .font(.title)
                    .foregroundStyle(.gray)
                Spacer()
            }
            
            Image("cachorro")
                .resizable()
                .scaledToFit()
                .frame(width: 500)
                .clipShape(/*@START_MENU_TOKEN@*/Circle()/*@END_MENU_TOKEN@*/)
            
            ForEach(meuArray, id: \.self) { frutas in 
                Text(frutas)
                    .padding(10)
            }
            
            MinhaView()
            Spacer()
        }
        .padding(40)
    }
}

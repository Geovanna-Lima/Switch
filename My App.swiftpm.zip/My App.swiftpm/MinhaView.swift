import SwiftUI

struct MinhaView: View {
    var body: some View {
        VStack {
            HStack {
                Text("Geovanna")
                    .font(.title)
                
                Spacer()
                
                Image("cachorro")
                    .resizable()
                    .scaledToFit()
                    .frame(width: 180)
                    .clipShape(/*@START_MENU_TOKEN@*/Circle()/*@END_MENU_TOKEN@*/)
                    .padding(.bottom, 20)
            }
            
            Text("Lorem ipsum dolor sit amet, consectetur adipiscing elit. Pellentesque congue, nunc at iaculis bibendum, lorem est condimentum enim, a dapibus neque enim et nibh. Nullam sapien diam, accumsan sit amet luctus at, venenatis eu eros. Fusce aliquet, lacus nec suscipit egestas, mi tellus commodo mauris, sed auctor lectus urna ut risus. Aenean ultricies tincidunt convallis. Orci varius natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Cras eu nulla tristique, tincidunt libero mattis, bibendum lacus. Suspendisse libero mi, pellentesque id nisl et, ultrices aliquet dolor. Donec molestie ligula a metus facilisis auctor. Integer scelerisque est metus, id sollicitudin sapien euismod ut.")
            
            Spacer()
        }
        .padding(20)
    }
}
